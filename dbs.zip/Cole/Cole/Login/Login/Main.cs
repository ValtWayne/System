﻿    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Data.SqlClient;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    namespace Login
    {
        public partial class Main : Form
        {
            public Main()
            {
                InitializeComponent();
                LoadItems();
            }
            private string CONNECTION_STRING = @"Data Source=desktop-nkhikgr\sqlexpress;Initial Catalog=Register;Integrated Security=True;";

            // Store the selected GroupBox for highlighting
            private DataRow selectedProduct; // Store the selected product's DataRow
            private GroupBox selectedGroupBox;

            // PictureBox click event handler
            private void PictureBox_Click(object sender, EventArgs e)
            {
                PictureBox pictureBox = sender as PictureBox;
                if (pictureBox != null)
                {
                    GroupBox groupBox = pictureBox.Parent as GroupBox;
                    if (groupBox != null)
                    {
                        DataRow productDataRow = groupBox.Tag as DataRow;
                        if (productDataRow != null)
                        {
                            // Retrieve product information from the selected PictureBox
                            string productName = productDataRow["product_name"].ToString();

                            // Store the selected product's DataRow
                            selectedProduct = productDataRow;

                            // Show message indicating the selected product
                            MessageBox.Show(productName + " is selected.");
                        }
                    }
                }
            }
        // Modify the LoadItems method to use checkboxes instead of labels
        private void LoadItems()
        {
            // Clear existing items
            GBSnacks.Controls.Clear();

            // Load items from the database
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                string query = "SELECT product_ID, product_name, price, image FROM products";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Create item controls for each row in the DataTable
                int itemIndex = 0; // Track the index of each item
                foreach (DataRow row in dataTable.Rows)
                {
                    if (itemIndex >= 4) break; // Limit to 4 items

                    // Create a GroupBox to contain each item
                    GroupBox groupBox = new GroupBox();
                    groupBox.Location = new Point(10 + itemIndex % 2 * 223, 15 + itemIndex / 2 * 183); // Adjusted location
                    groupBox.Margin = new Padding(3);
                    groupBox.Padding = new Padding(10); // Adjusted padding
                    groupBox.Size = new Size(219, 173); // Adjusted size
                    groupBox.Tag = row; // Store the DataRow for later use

                    // Create PictureBox for image
                    PictureBox pictureBox = new PictureBox();
                    pictureBox.Location = new Point(59, 19);
                    pictureBox.Margin = new Padding(3);
                    pictureBox.Padding = new Padding(0);
                    pictureBox.Size = new Size(100, 91);
                    pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                    pictureBox.Image = ByteArrayToImage((byte[])row["image"]);

                    // Attach PictureBox click event handler
                    pictureBox.Click += PictureBox_Click;

                    groupBox.Controls.Add(pictureBox);

                    // Create CheckBox for product selection
                    CheckBox checkBox = new CheckBox();
                    checkBox.AutoSize = true;
                    checkBox.Location = new Point(89, 113);
                    checkBox.Margin = new Padding(3, 5, 3, 0); // Adjusted margin
                    checkBox.Padding = new Padding(0);
                    checkBox.Size = new Size(100, 15); // Adjusted size
                    checkBox.Text = row["product_name"].ToString();
                    checkBox.CheckedChanged += (sender, e) =>
                    {
                        if (checkBox.Checked)
                        {
                            selectedProduct = row;
                            selectedGroupBox = groupBox;
                        }
                        else
                        {
                            selectedProduct = null;
                            selectedGroupBox = null;
                        }
                    };
                    groupBox.Controls.Add(checkBox);

                    // Create Label for price
                    Label priceLabel = new Label();
                    priceLabel.Location = new Point(89, 137);
                    priceLabel.Margin = new Padding(3, 0, 3, 0);
                    priceLabel.Padding = new Padding(0);
                    priceLabel.Size = new Size(100, 15); // Adjusted size
                    priceLabel.Text = "$" + row["price"].ToString();
                    groupBox.Controls.Add(priceLabel);

                    // Add the GroupBox to the form
                    GBSnacks.Controls.Add(groupBox);

                    itemIndex++; // Increment the item index
                }
            }
        }

        // Modify the AddItemToCart method to use the selected checkbox instead of the selected product
        private void AddItemToCart(string productID, string productName, decimal price, int quantity)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
                {
                    string query = "INSERT INTO cart (product_ID, product_name, price, qty) VALUES (@ProductID, @ProductName, @Price, @Quantity)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ProductID", productID);
                    command.Parameters.AddWithValue("@ProductName", productName);
                    command.Parameters.AddWithValue("@Price", price);
                    command.Parameters.AddWithValue("@Quantity", quantity);
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Item added to cart.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to add item to cart.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding item to cart: " + ex.Message);
            }
        }


        private void AdminProductAdded(object sender, EventArgs e)
            {
                // Reload items when a new product is added
                LoadItems();
            }
            // Subscribe to the ProductAdded event when AdminSide form is opened
            private void OpenAdminSide()
            {
                AdminSide adminSide = new AdminSide();
                adminSide.ProductAdded += AdminProductAdded;
                adminSide.ShowDialog();
            }

            private Image ByteArrayToImage(byte[] byteArray)
            {
                using (MemoryStream ms = new MemoryStream(byteArray))
                {
                    return Image.FromStream(ms);
                }
            }
            private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
            {

            }

            private void Main_Load(object sender, EventArgs e)
            {
                // TODO: This line of code loads data into the 'registerDataSet1.cart' table. You can move, or remove it, as needed.
                this.cartTableAdapter.Fill(this.registerDataSet1.cart);

            }

            private void GBSnacks_Enter(object sender, EventArgs e)
            {

            }

            private void ProductPictureBox_Click(object sender, EventArgs e)
            {

            }

            private void ProductNameLabel_Click(object sender, EventArgs e)
            {

            }

            private void PriceLabel_Click(object sender, EventArgs e)
            {

            }

            private void Picture2_Click(object sender, EventArgs e)
            {

            }

            private void ProductNameLabel2_Click(object sender, EventArgs e)
            {

            }

            private void PriceLabel2_Click(object sender, EventArgs e)
            {

            }

            private void pictureBox3_Click(object sender, EventArgs e)
            {

            }

            private void ProductNameLabel3_Click(object sender, EventArgs e)
            {

            }

            private void PriceLabel3_Click(object sender, EventArgs e)
            {

            }

            private void pictureBox2_Click(object sender, EventArgs e)
            {

            }

            private void ProductNameLabel4_Click(object sender, EventArgs e)
            {

            }

            private void PriceLabel4_Click(object sender, EventArgs e)
            {

            }

            private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
            {

            }

        // Button click event handler to add the selected item to the cart
        private void BTNAdd_Click(object sender, EventArgs e)
        {
            if (selectedProduct == null)
            {
                MessageBox.Show("Please select a product.");
                return;
            }

            // Retrieve product information from the selected product's DataRow
            string productID = selectedProduct["product_ID"].ToString();
            string productName = selectedProduct["product_name"].ToString();
            decimal price = Convert.ToDecimal(selectedProduct["price"]);

            // Prompt the user for the quantity
            int quantity;
            if (!int.TryParse(TBQTY.Text, out quantity) || quantity <= 0)
            {
                MessageBox.Show("Please enter a valid quantity.");
                return;
            }

            // Add the item to the cart
            AddItemToCart(productID, productName, price, quantity);
        }

        private void BTNUpdate_Click(object sender, EventArgs e)
            {

            }

            private void BTNRemove_Click(object sender, EventArgs e)
            {

            }

            private void TBQTY_TextChanged(object sender, EventArgs e)
            {

            }
        }
    }
